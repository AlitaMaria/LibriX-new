import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:learningapp/screens/bookclass.dart';
import 'package:learningapp/screens/provider.dart';
import 'package:provider/provider.dart';

class HomeClass extends StatelessWidget {
  HomeClass({super.key});


  @override
  Widget build(BuildContext context) {
       var size = MediaQuery.of(context).size;
    var height = size.height;
     var width = size.width;
    return Scaffold(
      body:  SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Text(
                    "Welcome back ",
                    style: TextStyle(
                      color: Color.fromARGB(255, 92, 42, 179),
                      fontSize: 30,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    context.watch<UserProvider>().userName.replaceAll("@gmail.com"," "),
                    style: TextStyle(
                      color: Color.fromARGB(255, 92, 42, 179),
                      fontSize: 30,
                      fontWeight: FontWeight.bold,
                    ),
                  )
                ],
              ),
              SizedBox(
                height: 30,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  SizedBox(
                    height: 50,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10)),
                          backgroundColor: Color.fromARGB(255, 92, 42, 179)),
                      onPressed: () { Navigator.push(context, MaterialPageRoute(builder: (context) => Bookclass(),));},
                      child: Text(
                        "Book Class",
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 50,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10)),
                          backgroundColor: Color.fromARGB(255, 92, 42, 179)),
                      onPressed: () {},
                      child: Text(
                        "My Courses",
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                  )
                ],
              ),
              Padding(
                padding: const EdgeInsets.all(10.0),
                child: Text(
                  "Last Classes",
                  style: TextStyle(
                    color: Color.fromARGB(255, 92, 42, 179),
                    fontSize: 25,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              // Carousel slider
              CarouselSlider(
                items: [
                  Material(
                    elevation: 10,
                    child: Container(
                      decoration: BoxDecoration(
                        boxShadow: [
                          BoxShadow(
                            blurRadius: 7.0,
                          )
                        ],
                      ),
                      margin: EdgeInsets.all(10),
                      child: Column(
                        children: [
                          Expanded(
                            child: Container(
                              padding: EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                  image: DecorationImage(
                                      image: NetworkImage(
                                          "https://static.vecteezy.com/system/resources/thumbnails/009/459/356/small/woman-school-or-college-teacher-education-worker-standing-near-blackboard-teacher-with-pointer-at-chalkboard-in-classroom-flat-illustration-vector.jpg"),
                                      fit: BoxFit.cover)),
                            ),
                          ),
                          Container(
                            color: Colors.white,
                            child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Align(alignment: Alignment.topLeft),
                                  Text(
                                    "Arts and Humanities",
                                    style: TextStyle(
                                      color: Color.fromARGB(255, 92, 42, 179),
                                      fontSize: 10,
                                    ),
                                  ),
                                  Text(
                                    "DRAW & PAINT ARTS",
                                    style: TextStyle(
                                      color: Color.fromARGB(255, 92, 42, 179),
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  Text(
                                    "2h 25 min",
                                    style: TextStyle(
                                      color: Color.fromARGB(255, 92, 42, 179),
                                      fontSize: 10,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  // Add other items similarly
                ],
                options: CarouselOptions(
                  height: height / 3.5,
                  autoPlay: true,
                  aspectRatio: 5 / 10,
                  autoPlayCurve: Curves.fastOutSlowIn,
                  enableInfiniteScroll: true,
                  autoPlayAnimationDuration: Duration(milliseconds: 80),
                  viewportFraction: 0.8,
                ),
              ),
       
            ],
          ),
        ),
    );
  }
}