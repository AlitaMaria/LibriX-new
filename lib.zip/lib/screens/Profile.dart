

import 'package:flutter/material.dart';
import 'package:learningapp/screens/loginpage.dart';
import 'package:learningapp/screens/provider.dart';
import 'package:provider/provider.dart';

class Profile extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.purple.shade50,
      
      body: Column(
        children: [
          Container(
            color:  Color.fromARGB(255, 92, 42, 179),
            padding: const EdgeInsets.all(16.0),
            child: Row(
              children: [
                CircleAvatar(
                  radius: 30,
                  backgroundColor: Colors.white,
                  child: Icon(
                    Icons.person,
                    size: 30,
                    color: Colors.purple,
                  ),
                ),
                SizedBox(width: 16),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children:  [
                    Text(
                      context.watch<UserProvider>().userName.replaceAll("@gmail.com"," "),
                      style: TextStyle(
                        fontSize: 25,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    Text(
                    context.watch<UserProvider>().userName,
                    style: TextStyle(
                      color:Colors.white,
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                    ),
                  )
                  ],
                ),
              ],
            ),
          ),
          Expanded(
            child: ListView(
              children: [
                _buildListTile('Account Setting', Icons.settings),
                _buildListTile('Document Upload', Icons.upload_file),
                _buildListTile('Notification Setting', Icons.notifications),
                _buildListTile('Privacy & Policy', Icons.privacy_tip),
                _buildListTile('Help Center', Icons.help),
                _buildListTile('About Us', Icons.info),
                _buildListTile('Delete Account', Icons.delete, Colors.black),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: SizedBox(
              height: 45,
              width: 150,
              child: ElevatedButton(
                onPressed: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context)=>Loginpage()));
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor:  Color.fromARGB(255, 92, 42, 179),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                 shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(15))
                 
                ),
                child: const Text(
                  'Log Out',
                  style: TextStyle(fontSize: 16,color:Colors.white),
                ),
              ),
            ),
          ),
        ],
      ),
      
    );
  }

  ListTile _buildListTile(String title, IconData icon, [Color? color]) {
    return ListTile(
      leading: Icon(icon, color: color ?? Colors.black),
      title: Text(title),
      trailing: const Icon(Icons.arrow_forward_ios, size: 16),
      onTap: () {},
    );
  }

}