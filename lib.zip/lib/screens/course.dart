import 'package:flutter/material.dart';

import 'package:learningapp/screens/homescreen.dart';



import 'package:learningapp/screens/loginpage.dart';
 class Course extends StatefulWidget {
  const Course({super.key});

  State<Course> createState() => _CourseState();
}

class _CourseState extends State<Course> {
  String? choice= null;
  bool value= false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
         backgroundColor: Colors.white,
       leading: IconButton(onPressed: (){
        Navigator.push(context,MaterialPageRoute(builder: (context)=> Loginpage(),));
       }, icon: Icon(Icons.arrow_back_ios, color: Color.fromARGB(255, 92, 42, 179),)),),
      
     backgroundColor: Colors.white,
      
      body: SafeArea(
        
        child: SingleChildScrollView(
          child: Column(
            children: [
              Text("Learning App",
               style: TextStyle(
                            color: Color.fromARGB(255, 92, 42, 179),
                            fontSize: 25,
                            fontWeight: FontWeight.bold),
                      ),
              Container(
                height: 350,
                width: 300,
                child: Image.asset(
                  
                  "assets/image.webp"),
              ),
              Text("Select your course level",
              style:  TextStyle(
                            color: Color.fromARGB(255, 92, 42, 179),
                            fontSize: 20,
                            fontWeight: FontWeight.bold),),
                            Padding(padding: EdgeInsets.all(10)),
              Row(
                children: [
                  Expanded(child: ChoiceChip(label: Text("Beginner"), selected:choice=="Beginner",
                  onSelected: (bool selected){
                    setState(() {
                      choice = selected?"Beginner": null;
                      
                    });
                  },)),
          
                   Expanded(child: ChoiceChip(label: Text("Intermediate"), selected:choice=="Intermediate",
                  onSelected: (bool selected){
                    setState(() {
                      choice = selected?"Intermediate": null;
                      
                    });
                  },)),
                  Expanded(child: ChoiceChip(label: Text("Expert"), selected:choice=="Expert",
                  onSelected: (bool selected){
                    setState(() {
                      choice = selected?"Expert": null;
                    });
                  },)),
                  
                ],
              ),
              Row(
                    children: [
                      Checkbox(
                                
                                value: value,
                                onChanged: (bool? newvalue) {
                                  setState(() {
                                    value = newvalue!;
                                  });
                                },
                                activeColor: Colors.black,
                                ),
                                Padding(padding: EdgeInsets.only(left: 4)),
                                Text("Are you sure?")
                    ],
                  ),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      disabledBackgroundColor: Colors.grey,
                      backgroundColor:Color.fromARGB(255, 92, 42, 179),
          
                    ),
          
          onPressed: (value && choice != null)?
             ()=>Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) =>Homrscreen())):null,
          
                                //  onPressed: (){
                                //   if(value == true && choice=="Beginner" ){
                                //     Navigator.push(context, MaterialPageRoute(builder: (context)=>Beginner()));
                                //   }
                                //   else if(value == true && choice=="Intermediate" ){
          
                                //     Navigator.push(context, MaterialPageRoute(builder: (context)=>Intermediate()));
          
                                //   }
                                //    else if(value == true && choice=="Expert" ){
          
                                //     Navigator.push(context, MaterialPageRoute(builder: (context)=>Expert()));
          
                                //   }
                                //  },
                                 
                     child: Text("Continue",style: 
                     TextStyle(color: Colors.white),)),
                    
            ],
          ),
        ),
      )
    );
  }
}