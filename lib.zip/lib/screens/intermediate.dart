import 'package:flutter/material.dart';

class Intermediate extends StatelessWidget {
  const Intermediate({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Text("you are now in intermediate",
      style: TextStyle(fontSize: 30),
      ),
    );
  }
}