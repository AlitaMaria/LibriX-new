import 'package:flutter/material.dart';
import 'package:learningapp/screens/loginpage.dart';

class CreateAcc extends StatelessWidget {
  const CreateAcc({super.key});

  @override
  Widget build(BuildContext context) {
    TextEditingController emailcontroller=TextEditingController();
    TextEditingController namecontroller=TextEditingController();
    TextEditingController passwordcontroller=TextEditingController();
    return Scaffold(
      appBar: AppBar(
         leading: IconButton(onPressed: (){
        Navigator.push(context,MaterialPageRoute(builder: (context)=> Loginpage(),));
       }, icon: Icon(Icons.arrow_back_ios, color: Color.fromARGB(255, 92, 42, 179),)),
        title: Padding(
          padding: const EdgeInsets.only(left: 15),
          child: Text("Create New Account", style: TextStyle(
                    color: Color.fromARGB(255, 92, 42, 179),
                    fontWeight: FontWeight.bold, fontSize: 20),),
        ),
      ),

      body: Padding(
        padding: const EdgeInsets.all(15),
        child: Center(
          
          child: Column(
            crossAxisAlignment:CrossAxisAlignment.center,
            children: [
              
              SizedBox(
                height: 50,
                width: 300,
                child: TextField(
                  
                        controller: emailcontroller,
                        decoration: InputDecoration(
                          
                           border: OutlineInputBorder(),
                            labelText: "Email",
                            hintText: "Email",
                            labelStyle:  TextStyle( color:  Color.fromARGB(255, 92, 42, 179)),
                           ),
                      ),
              ),
        Padding(padding: EdgeInsets.all(20)),
                    SizedBox(
                       height: 50,
                width: 300,
                      child: TextField(
                        controller: passwordcontroller,
                        decoration: InputDecoration(
                          
                            labelText: "Password",
                            hintText: "Password",
                            border: OutlineInputBorder()),
                      ),
                    ),
        
        Padding(padding: EdgeInsets.all(20)),
                    SizedBox(
                       height: 50,
                width: 300,
                      child: TextField(
                        
                        controller: passwordcontroller,
                        decoration: InputDecoration(
                          
                            labelText: "Confirm Password",
                            hintText: "Confirm",
                            border: OutlineInputBorder()),
                      ),
                    ),
 Padding(padding: EdgeInsets.all(20)),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                    backgroundColor:Color.fromARGB(255, 92, 42, 179)),
                      onPressed: (){
                       // if(){}
                      }, child: Text("Submit",style: TextStyle(color: Colors.white, fontSize: 18),)),
            ],
          ),
          
        ),
      ),
    );
  }
}