import 'package:flutter/material.dart';

class Beginner extends StatelessWidget {
  const Beginner({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Text("you are now in beginner",
      style: TextStyle(fontSize: 30),
      ),
    );
  }
}