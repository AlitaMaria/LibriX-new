import 'package:flutter/material.dart';

class Expert extends StatelessWidget {
  const Expert({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Text("you are now in expert level",
      style: TextStyle(fontSize: 30),
      ),
    );
  }
}