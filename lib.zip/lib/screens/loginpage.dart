import 'package:flutter/material.dart';
import 'package:learningapp/screens/course.dart';
import 'package:learningapp/screens/createacc.dart';
import 'package:learningapp/screens/home.dart';
import 'package:learningapp/screens/provider.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';


class Loginpage extends StatefulWidget {
  const Loginpage({super.key});

  @override
  State<Loginpage> createState() => _LoginpageState();
}

class _LoginpageState extends State<Loginpage> {
  bool value = false;
  TextEditingController emailcontroller=TextEditingController();
  TextEditingController passwordcontroller=TextEditingController();

  var facebookurl="https://en-gb.facebook.com/login/web/";
  var Googleurl="https://www.google.co.in/";

  Future<void>_launcherUrlfacebook()async{
    final Uri url=Uri.parse(facebookurl)
    ;

    if(await canLaunchUrl(url)){
      await launchUrl(url);

    }

    else{
      throw"error in the url: $facebookurl";
    }
  }

  Future<void>_launcherUrlgoogle()async{
    final Uri url=Uri.parse(Googleurl)
    ;

    if(await canLaunchUrl(url)){
      await launchUrl(url);

    }

    else{
      throw"error in the url: $Googleurl";
    }
  }
  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
         leading: IconButton(onPressed: (){
        Navigator.push(context,MaterialPageRoute(builder: (context)=> Home(),));
       }, icon: Icon(Icons.arrow_back_ios, color: Color.fromARGB(255, 92, 42, 179),)),
        title: Row(
          children: [
            SizedBox(
              width: 80,
            ),
            Text(
              "LOG IN",
              style: TextStyle(
                  color: Color.fromARGB(255, 92, 42, 179),
                  fontWeight: FontWeight.bold, fontSize: 20),
            ),
          ],
        ),
      ),
      body: Center(
        child: ListView(
          children: [
            Center(
                child: Text("Learning App",
                    style: TextStyle(
                        color: Color.fromARGB(255, 92, 42, 179),
                        fontSize: 30,
                        fontWeight: FontWeight.bold))),
            Padding(padding: EdgeInsets.all(15)),
            Center(
                child: Text("Enter your log in details to access your account",
                    style: TextStyle(
                        color: Color.fromARGB(255, 92, 42, 179),
                        fontSize: 15,
                        fontWeight: FontWeight.bold))),
            Padding(padding: EdgeInsets.only(bottom: 25)),
            Row(
              
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                SizedBox(
                  width: 160,
                  height: 60,
                  child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(15)),
                          backgroundColor:
                              const Color.fromARGB(255, 8, 107, 188)),
                      onPressed: () {_launcherUrlfacebook();},
                      child: Row(
                        children: [
                          Icon(
                            Icons.facebook,
                            color: Colors.white,
                          ),
                          Text(
                            "Facebook",
                            style: TextStyle(color: Colors.white, fontSize: 20),
                          )
                        ],
                      )),
                ),
                SizedBox(
                  width: 160,
                  height: 60,
                  child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(15)),
                          backgroundColor:
                              const Color.fromARGB(255, 227, 14, 103)),
                      onPressed: () {
                        _launcherUrlgoogle();
                      },
                      child: Row(
                        children: [
                          Icon(
                            Icons.g_mobiledata,
                            color: Colors.white,
                          ),
                          Text(
                            "Google",
                            style: TextStyle(color: Colors.white, fontSize: 20),
                          )
                        ],
                      )),
                )
              ],
            ),
            SizedBox(
              height: 30,
            ),
            Padding(
              padding: const EdgeInsets.all(15),
              child: TextField(
                controller: emailcontroller,
                decoration: InputDecoration(
                  
                    labelText: "Email",
                    hintText: "Email",
                    border: OutlineInputBorder()),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(15),
              child: TextField(
                controller: passwordcontroller,
                obscureText: true,
                decoration: InputDecoration(
                  
                    labelText: "Password",
                    hintText: "Password",
                    border: OutlineInputBorder()),
              ),
            ),
            Row(
              children: [
                Row(
                  children: [
                    Checkbox(
                        tristate: true,
                        value: value,
                        onChanged: (bool? newvalue) {
                          setState(() {
                            value = newvalue!;
                          });
                        }),
                    Text(
                      "Remember Me ?",
                      style: TextStyle(
                        color: Color.fromARGB(255, 92, 42, 179),
                      ),
                    )
                  ],
                ),
                SizedBox(
                  width: 80,
                ),
                TextButton(
                    onPressed: () {},
                    child: Text(
                      "Forgot Password?",
                      style: TextStyle(color: Colors.red),
                    )),
              ],
            ),
            Padding(padding: EdgeInsets.all(10)),
            Padding(
              padding: const EdgeInsets.only(left: 50, right: 50),
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                    backgroundColor:Color.fromARGB(255, 92, 42, 179)),
                onPressed: () {
                  final email=emailcontroller.text.trimRight();
                  if(email.isNotEmpty)
                  {
                    
                  }
                  // final Password=passwordcontroller.text;
                  context.read<UserProvider>().changeUsername(newUsername:emailcontroller.text);
                  emailcontroller.clear();
                  passwordcontroller.clear();
                  Navigator.push(context, MaterialPageRoute(builder: (context) => Course(),));
                },
                child: Text(
                  "Login with your account",
                  style: TextStyle(color: Colors.white, fontSize: 18),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 50, top: 40),
              child: Center(
                child: Row(
                  children: [
                    Text(
                      "Don't have an account?",
                      style: TextStyle(color: Color.fromARGB(255, 92, 42, 179)),
                    ),
                    TextButton(
                        onPressed: () {
                          Navigator.push(context, MaterialPageRoute(builder: (context)=> CreateAcc()));
                        },
                        child: Text("Create Account",
                            style: TextStyle(
                                color: Color.fromARGB(255, 80, 22, 243))))
                  ],
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}