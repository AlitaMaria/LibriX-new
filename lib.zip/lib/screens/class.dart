import 'package:flutter/material.dart';

import 'package:learningapp/screens/homescreen.dart';

class Class extends StatefulWidget {
  const Class({super.key});

  @override
  State<Class> createState() => _ClassState();
}

class _ClassState extends State<Class> {
   

  @override
  Widget build(BuildContext context) {
    
  
    return Scaffold(
      
      
      
        
    
       
    );
  }
}